import { ARBIWebMonitor2Page } from './app.po';

describe('arbiweb-monitor2 App', () => {
  let page: ARBIWebMonitor2Page;

  beforeEach(() => {
    page = new ARBIWebMonitor2Page();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
