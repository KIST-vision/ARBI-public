import {MonitorModule} from '../module/base.module'
export class Agent {
  private _name: string;
  private _components: Array<MonitorModule>;

  get components():Array<MonitorModule>{
    return this._components;
  }
  set components(__components : Array<MonitorModule>){
    this._components = __components;
  }

  get name():string{
    return this._name;
  }
  set name(__name : string){
    this._name = __name;
  }

  constructor(name: string){
    this._name = name;
    this._components = new Array<MonitorModule>();
  }
}
