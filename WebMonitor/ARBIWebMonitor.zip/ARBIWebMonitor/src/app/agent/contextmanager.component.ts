import { Component, OnInit } from '@angular/core';
import {ContextManagerService} from './contextmanager.service'
import {GraphicModel} from '../module/common/graph.component'


@Component({
  selector: 'agent-contextmanager',
  template: `<div fxLayout="row" fxLayoutWrap fxLayoutAlign="space-around">
    <workingmemory fxFlex=100 [perception]="data.perception" [monitor]="data.monitor" [triple]="data.triple"></workingmemory>
    <reasoning-graphs fxFlex=100 fxLayoutAlign="space-around" [lowlevel]="lowGraphicModel" [highlevel]="highGraphicModel"></reasoning-graphs>
    <context-graphs fxFlex=50 fxLayoutAlign="space-around" [knowledgeCount]="data.perception" [knowledgeGraphicModel]="knowledgeGraphicModel"></context-graphs>
    <robot-graphs fxFlex=50 fxLayoutAlign="space-around" [availableBattery]="batteryGraphicModel" [isCharging]="data.availableBattery.isCharging"></robot-graphs>
    <context-async fxFlex=100 [model]="data.contextService"></context-async>
    <context-service fxFlex=50 fxLayoutAlign="space-around" [query]="data.query" [contextService]="data.contextService" [perception]="data.latestPerception"></context-service>

    <!--<context-sync fxFlex=100 [model]="data.query"></context-sync>-->

  </div>`,
})
export class ContextManagerComponent implements OnInit {
  private isContextCollapsed = true;
  private data = {
    reasoning:{
      low:[10],
      high:[10],
      time:[1423]
    },
    availableBattery:{
      "free":0,
      "used":100,
      "isCharging":"Charging"
    },
    perception : 0,
    monitor : 0,
    triple: 0,
    query : [],
    latestPerception:{
      user:"alpha",
      object:"beta",
      voice:"gamma",
      location:"delta"
    },
    // sn:{
    //   predicate: [],
    //   notify: []
    // },
    contextService:{
      predicate:[],
      notify:[],
      count:{
        current:0,
        array:[]
      }
    }
  }
  private knowledgeGraphicModel:GraphicModel = new GraphicModel([{"data":[1,2,3,4,5],"label":"x"}], ["a","b","c","d","e"]);
  private batteryGraphicModel:GraphicModel = new GraphicModel([{"data":[75,25],"label":["x"]}],["used","free"])

  private contextServiceGraphicModel:GraphicModel = new GraphicModel([{"data":[1,2,3,4,5],"label":"x"}],["a","b","c","d","e"]);

  private lowGraphicModel:GraphicModel = new GraphicModel([{"data":[0],"label":"x"}],["144050120"]);
  private highGraphicModel:GraphicModel = new GraphicModel([{"data":[1,2,3,4,5],"label":"x"}],["144050120"]);

  private knowledgegm = {
    data:[1,2,3,4,5],
    label:["a","b","c","d","e"]
  }
  constructor(private cont:ContextManagerService) {
    cont.eventInvoke.subscribe((message:string)=>{

      let obj = JSON.parse(message);

      // console.log("event invoked: "+JSON.stringify(obj));

      console.log(obj.perception + " / " + obj.monitor + " / " + obj.triple);

      this.data.perception = obj.perception;
      this.data.monitor = obj.monitor;
      this.data.triple = obj.triple;
      this.data.query = obj.query;
      // this.data.sn = obj.sn;
      this.data.contextService = obj.contextService;

      this.data.latestPerception = obj.latestPerception

      this.data.availableBattery = obj.availableBattery;

      // this.batteryGraphicModel.chartData[0] = this.data.availableBattery.used;
      // this.batteryGraphicModel.chartData[1] = this.data.availableBattery.free;
      this.batteryGraphicModel = new GraphicModel([{"label":"x","data":[this.data.availableBattery.used,this.data.availableBattery.free]}], ["used","free"])

      let highlowLabel:any = obj.reasoning.time;

      this.lowGraphicModel = new GraphicModel([{"data":obj.reasoning.low,"label":"low"}], highlowLabel);
      this.highGraphicModel = new GraphicModel([{"data":obj.reasoning.high,"label":"high"}],highlowLabel);

      let workingMemoryLabel:any;
      let contextServiceLabel:any;

      let knowledgeChartData:any;

      let _wm = obj.workingMemory;

      if(obj.workingMemory.label.length > 20){
        workingMemoryLabel = _wm.label.slice(_wm.label.length-5, _wm.label.length);
        knowledgeChartData = _wm.knowledge.slice(_wm.knowledge.length-5, _wm.knowledge.length);
      } else {
        workingMemoryLabel = _wm.label;
        knowledgeChartData = _wm.knowledge;
      }

      this.knowledgeGraphicModel.chartLabel = workingMemoryLabel;

      this.knowledgeGraphicModel = new GraphicModel([{"data":knowledgeChartData,"label":"knowledge"}],workingMemoryLabel);

      this.contextServiceGraphicModel.chartLabel = contextServiceLabel;
      // console.log("reasoning graphic models " + JSON.stringify(this.lowGraphicModel));
      // console.log("reasoning graphic models " + JSON.stringify(this.highGraphicModel));
    })
   }
  ngOnInit() {
    console.log("CM on Init");
  }
}
