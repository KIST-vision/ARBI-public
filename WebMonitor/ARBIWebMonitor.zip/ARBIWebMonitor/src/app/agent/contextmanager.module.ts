import { NgModule } from '@angular/core';

import {CommonModule} from '@angular/common'
import { FlexLayoutModule } from '@angular/flex-layout';

import {ContextManagerComponent} from '../agent/contextmanager.component'
import {  ContextSync,
          ContextAsync,
          WorkingMemory,
          ContextGraphComponent,
          RobotGraphsComponent,
          ContextServiceComponent,
          ReasoningGraphsComponent } from '../module/contextmanager';
import {CommonComponentModule} from '../module/common/module'

import {CollapseModule} from 'ngx-bootstrap';

@NgModule({
  imports: [CommonModule, FlexLayoutModule, CommonComponentModule, CollapseModule],
  declarations: [ContextManagerComponent, ContextSync, ContextAsync, WorkingMemory, ContextGraphComponent, RobotGraphsComponent, ContextServiceComponent, ReasoningGraphsComponent],
  exports:[ContextManagerComponent],
  providers: []
})
export class ContextManagerModule { }
