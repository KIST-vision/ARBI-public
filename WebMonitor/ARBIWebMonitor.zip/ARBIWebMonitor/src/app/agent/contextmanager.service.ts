import { Injectable } from '@angular/core';

import {HubService, SystemMessage} from '../communication/hub.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Injectable()
export class ContextManagerService {
  private dataManager = {
    reasoning:{
      low:[],
      high:[],
      time:[]
    },
    perception : 0,
    monitor : 0,
    triple : 0,
    query: [],
    availableBattery:{
      "used":0,
      "free":100,
      "isCharging":"Not Charging"
    },
    workingMemory: {
      push:function(content:any, time:number){
        console.log("Workingmemory content = " + JSON.stringify(content));

        console.log("Time : " + time);
        let timestr =  new Date(time).getMinutes() + ":" + new Date(time).getSeconds();
        this.label.push(timestr);
        this.knowledge.push(content.used);
      },
      knowledge:[],
      label:[]
    },
    contextService:{
      push: (content, action) => {
        this.dataManager.contextService.count++;
        switch(action){
          case "query":
            this.dataManager.query.push({
              Sender : content.sender,
              Time : content.reasoningTime,
              QueryGL : content.queryGL,
              QueryProlog : content.queryToProlog,
              Response : content.queryResult
            })
            break;
          case "notify":
            var notifyObj = {
              key : content.predicate,
              tiem: content.reasoningTime,
              notify : content.notify,
              GL : "",
              subscriber : ""
            }
            for(let i=0;i<this.dataManager.contextService.predicate.length;i++){
              if(this.dataManager.contextService.predicate[i].key == notifyObj.key){
                notifyObj.GL = this.dataManager.contextService.predicate[i].GL;
                notifyObj.subscriber = this.dataManager.contextService.predicate[i].subscriber;
              }
            }
            this.dataManager.contextService.notify.push(notifyObj);
            break;
          case "subscribe":
            var subscribeObj = {
              prolog : content.subscribeGLToProlog,
              GL: content.subscribeGL,
              subscriber : content.subscriber
            }
            this.dataManager.contextService.predicate.push(subscribeObj);
            break;
          default:
            console.error("Function Missmatch Error!");
            break;
        }
      },
      count:0,
      predicate:[],
      notify:[]
    },
    latestPerception:{
      push:function(content){
        this.count++;
        let type = content.perceptionType;
        switch(type){
          case "User":
            this.user = content.contents;
            break;
          case "Object":
            this.object = content.contents;
            break;
          case "Voice":
            this.voice = content.contents;
            break;
          case "LatestRobotLocation":
            this.location = content.contents;
            break;
          default:
            console.error("Perception Type Missmatch Error!");
            console.error("Current content = " + content);
        }
      },
      user:"",
      object:"",
      voice:"",
      location:"",
      count:0
    },
    save: function(){
      localStorage.setItem("contextmanager",JSON.stringify(this.toObject()));
    },
    init: function(perception, monitor, triple, query, predicate, notify){
      this.perception = perception;
      this.monitor = monitor;
      this.triple = triple;
      this.query = query;
      this.sn.predicate = predicate;
      this.sn.notify = notify;
    },
    toObject: function(){
      let obj = {
        reasoning: this.reasoning,
        perception : this.perception,
        monitor : this.monitor,
        triple: this.triple,
        query : this.query,
        availableBattery:this.availableBattery,
        // sn:{
        //   predicate: this.sn.predicate,
        //   notify: this.sn.notify
        // },
        contextService:{
          predicate:this.contextService.predicate,
          notify:this.contextService.notify,
          count:this.contextService.count
        },
        latestPerception:{
          user:this.latestPerception.user,
          object:this.latestPerception.object,
          voice:this.latestPerception.voice,
          location:this.latestPerception.location
        },
        workingMemory:{
          knowledge:this.workingMemory.knowledge,
          label:this.workingMemory.label
        }
      }
      console.log(obj);
      return obj;
    }
  }

  private messages:Observable<SystemMessage>;
  private subscription: Subscription;

  public eventInvoke = new Subject<string>();

  private tickInterval:any;

  private graphTick(mills:number){
    this.tickInterval = setTimeout(()=>{
      console.log(this.dataManager.contextService.count);
      console.log(this.dataManager.latestPerception.count);
      this.dataManager.reasoning.high.push(this.dataManager.contextService.count);
      this.dataManager.reasoning.low.push(this.dataManager.latestPerception.count);
      let timestr =  new Date().getMinutes() + ":" + new Date().getSeconds();
      this.dataManager.reasoning.time.push(timestr);
      this.dataManager.contextService.count = 0;
      this.dataManager.latestPerception.count = 0;
      console.log("tick");
      console.log("reasonings = " + JSON.stringify(this.dataManager.reasoning))
      this.draw();
      this.graphTick(mills)

    },mills)
  }

  constructor(private _hub:HubService) {
    this.messages = _hub.subscribeSystemMessage()
    this.subscription = this.messages.subscribe(this.on_next)

    this.graphTick(60000)

    // let storage_str = localStorage.getItem("contextmanager");
    // if(storage_str == null || storage_str == "undefined") return;

    // let storage = JSON.parse(localStorage.getItem("contextmanager"));
    // this.dataManager.init(storage.perception, storage.monitor, storage.triple, storage.query, storage.sn.predicate, storage.sn.notify);
  }

  public on_next = (message: any) => {
    let msg;
    if(typeof msg == "string")
      msg = JSON.parse(message);
    else
      msg = message;


    if(msg.Actor == "contextManager"){
      this.parseSystemMessage(msg);
      this.draw();
    }

    // this._invokeEvent.next(this.agentConversationLogManager.toString());
    // this.agentConversationLogManager.save();
    // this.dataManager.save();

  }

  private parseSystemMessage(message:any){
    console.log("CM PARSING" + JSON.stringify(message));

    let mobj = {content : message.Content, time : message.Time, type:message.Type, action:message.Action}
    console.log(mobj.content.replace(/&quot;/g,'"').replace(/&apos;/g,"'"));
    let content = JSON.parse(mobj.content.replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/\n/g,"linebreak"));
    switch(mobj.type){
      case "sendLogQuery":
        this.dataManager.query.push({
          Sender : content.sender,
          Time : content.reasoningTime,
          QueryGL : content.queryGL,
          QueryProlog : content.queryToProlog,
          Response : content.queryResult
        })
        break;
      // case "sendLogSubscribe":
      //   this.dataManager.sn.push(mobj.content, mobj.action);
      //   break;
      // case "sendLogNotify":
      //   this.dataManager.sn.push(mobj.content, mobj.action);
      //   break;
      case "Counting":
        switch(mobj.action){
          case "triple":
            this.dataManager.triple = Number(content.triple);
            break;
          case "perception":
            this.dataManager.perception = Number(content.perception);
            break;
          case "monitor":
            this.dataManager.monitor = Number(content.monitor);
            break;
        }
        break;
      case "WorkingMemory":
        console.log("pushing workingMEmory : " + JSON.stringify(content));
        this.dataManager.workingMemory.push(content, Number(mobj.time));
        break;
      case "ContextService":
        this.dataManager.contextService.push(content, mobj.action);
        break;
      case "RobotContext":
        switch(mobj.action){
          case "availableBattery":
            console.log("available Battery Incomming!" + JSON.stringify(content));
            this.dataManager.availableBattery.free = content.available;
            this.dataManager.availableBattery.used = 100 - content.available;

            this.dataManager.availableBattery.isCharging = (content.status==0)?"Not Charging":"Charging";
            break;
          case "LatestPerception":
            console.log("Latest Perception Incomming : " + JSON.stringify(content));
            this.dataManager.latestPerception.push(content);
            break;
          default:
            console.error("RobotContext Actiontype Missmatch")
            break;
        }

        break;
      default:
        console.log("Error in CM Parse code");
        console.log(message);
        break;
    }
  }

  public draw(){
    console.log("Draw called!");
    console.log(this.eventInvoke);
    this.eventInvoke.next(JSON.stringify(this.dataManager.toObject()));
  }
}
