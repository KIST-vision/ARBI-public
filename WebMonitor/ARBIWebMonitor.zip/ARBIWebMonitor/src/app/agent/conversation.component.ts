import { Component, OnInit } from '@angular/core';
import {HubService, AgentMessage} from '../communication/hub.service';
import {ConversationService} from './conversation.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

declare var sequenceDiagram: any;

@Component({
  selector: 'agent-conversation',
  template: `<div id="agent-conversation-container" class="diagram-xl"></div>`
})
export class ConversationComponent implements OnInit {

  private refreshConversationDiagram(message:string){
    if(document.getElementById("agent-conversation-container") == null) return;

    let eStyle = document.getElementById("columns-css");
    let diagram = sequenceDiagram.fromText(message);

    // console.log(diagram);

    // console.log(message);

    let html = diagram.toHtml();

    eStyle.innerHTML = diagram.generateCss();
    document.getElementById("agent-conversation-container").innerHTML = html;

  }

  constructor(private _conv:ConversationService) {
    this._conv.invokeEvent.subscribe(message => this.refreshConversationDiagram(message))
    this._conv.draw();
   }

  private testFunction1(){
    let eStyle = document.getElementById("columns-css");
    let diagram = sequenceDiagram.fromText("A, B, C, D\nA --> B: what the\nB --> C: hell was");

    let html = diagram.toHtml();

    eStyle.innerHTML = diagram.generateCss();
    document.getElementById("agent-conversation-container").innerHTML = html;
  };

  ngOnInit() {
//    this.refreshConversationDiagram();
    this.testFunction1();
  }
}
