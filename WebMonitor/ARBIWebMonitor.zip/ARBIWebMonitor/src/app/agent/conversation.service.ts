import { Injectable,OnDestroy } from '@angular/core';
import {HubService, AgentMessage} from '../communication/hub.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Injectable()
export class ConversationService implements OnDestroy{
  private agentConversationLogManager = {
    log:[],
    agents:[],
    conversations:[],
    push:function(message : AgentMessage){
      let _log = new AgentConversationLog(
        message.Sender.replace("agent://www.arbi.com/","").replace("agent://arbi.com/",""),
        message.Receiver.replace("agent://www.arbi.com/","").replace("agent://arbi.com/",""),
        message.Content, message.Action);
      if(!this.agents.includes(_log.Receiver)) this.agents.push(_log.Receiver);
      if(!this.agents.includes(_log.Sender)) this.agents.push(_log.Sender);

      this.log.push(message);
      this.conversations.push(_log);
    },
    toString: function():string{
      let res = "what";
      res = this.agents.toString() + "\n";

      this.conversations.reverse().forEach(function(message:AgentConversationLog) {
        // console.log("now looping");
        // console.log(message);
        res += message.Sender + " --> " + message.Receiver + ": " + message.Action + " " + message.Content.replace(/:/gi,"colon").replace(/\n/g,"linebreak") + "\n"
      });

      return res
    },
    initialize : function(_log, _agents, _conversations){
      // console.log("lets init")
      this.log = _log;
      this.agents = _agents;
      _conversations.forEach(message => {
        this.conversations.push(new AgentConversationLog(message._sender,message._receiver,message._content,message._action))
      });
    },
    toObject : function():object{
      return {
        "log":this.log,
        "agents":this.agents,
        "conversations":this.conversations
      };
    },
    save: function(){
      localStorage.setItem("conversationLog",JSON.stringify(this.toObject()));
    }
  }

  private messages : Observable<AgentMessage>;
  private subscription: Subscription;

  private _invokeEvent:Subject<string> = new Subject<string>();

  constructor(private _hub: HubService) {
    // let storage = localStorage.getItem("conversationLog");
    // if(storage != null && storage != "undefined"){
    //   let obj = JSON.parse(storage);
    //
    //   this.agentConversationLogManager.initialize(obj.log, obj.agents, obj.conversations);
      // console.log(this.agentConversationLogManager.toString())
    //   setTimeout(()=>this._invokeEvent.next(this.agentConversationLogManager.toString()),100);
    // }
    this.messages = _hub.subscribeAgentMessage()
    this.subscription = this.messages.subscribe(this.on_next)
    // console.log("construct complete");
  }

  public draw(){
    setTimeout(()=>this._invokeEvent.next(this.agentConversationLogManager.toString()),100);
  }

  ngOnDestroy(){
    // console.log("on destroy");
    // console.log(this.agentConversationLogManager.toObject());
    this.agentConversationLogManager.save();
  }

  public on_next = (message: AgentMessage) => {
    // console.log("this is message")
    // console.log(message);
    this.agentConversationLogManager.push(message);
    this._invokeEvent.next(this.agentConversationLogManager.toString());
    this.agentConversationLogManager.save();
  }

  get invokeEvent():Subject<string>{
    return this._invokeEvent;
  }
}

class AgentConversationLog {
  private _sender:string;
  private _receiver:string;
  private _content:string;
  private _action:string;

  constructor(sender:string, receiver:string, content:string, action:string){
    this._sender = sender;
    this._receiver = receiver;
    this._content = content;
    this._action = action;
    }

  get Sender():string{
    return this._sender;
  }
  get Receiver():string{
    return this._receiver;
  }
  get Content():string{
    return this._content;
  }
  get Action():string{
    return this._action;
  }


}
