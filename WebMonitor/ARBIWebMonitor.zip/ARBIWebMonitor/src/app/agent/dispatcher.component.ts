import { Component, OnInit } from '@angular/core';
import {ServicePackageDispatcherService} from './dispatcher.service'

@Component({
  selector: 'agent-dispatcher',
  template: `
    <div fxLayout="row" fxLayoutWrap fxLayoutAlign="space-around">
      <!--<service-filelist [model]="dataManager.fileList"></service-filelist>-->
      <service-fileview title="Plan" [model]="dataManager.plan"></service-fileview>
      <service-fileview title="Knowledge" [model]="dataManager.knowledge"></service-fileview>
      <service-fileview title="Reasoning Rule" [model]="dataManager.rule"></service-fileview>
      <service-fileview title="Robot" [model]="dataManager.robot"></service-fileview>
    </div>
  `,
})
export class ServicePackageDispatcherComponent implements OnInit {

  /*{"Name":"file.owl","Content":content string here}*/

  /*["a,owl","b.owl","c.owl" etc etc]*/

  private dataManager = {
    fileList:{
      Title:"Service Package Not Loaded",
      Content:["No File"]
    },
    knowledge:[],
    plan:[],
    rule:[],
    robot:[]
  }

  constructor(private spd:ServicePackageDispatcherService) {
    this.spd.getEventInvoke().subscribe(message => {
      this.parseSystemMessage(message);
    })
  }

  private parseSystemMessage(msg:any){
    let message;
    console.log(msg);
    if(typeof msg == "string"){
      message = JSON.parse(msg);
    } else {
      message = msg;
    }

    console.log("Package Dispatcher Message = " + msg);

    let content;

    if(typeof msg.Content == "string"){
      content = msg.Content.replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/	/g,"tab").replace(/\t/g,"tab").replace(/\n/g,"linebreak").replace(/\"Work\"/g,"Work");
      console.log(content);
      content = JSON.parse(content);
    }
    else
      content = msg.Content;

    switch(msg.Action){
      case "List":
        this.dataManager.fileList.Title = content.Name;
        this.dataManager.fileList.Content = content.Content;
        this.dataManager.knowledge = [];
        this.dataManager.plan = [];
        this.dataManager.rule = [];
        this.dataManager.robot = [];
        break;
      case "Load":
        content.isCollapsed = true;
        switch(msg.Type){
          case "Knowledge":
            this.dataManager.knowledge.push(content);
            break;
          case "Plan":
            this.dataManager.plan.push(content);
            break;
          case "Rule":
            this.dataManager.rule.push(content);
            break;
          case "Robot":
            this.dataManager.robot.push(content);
            break;
        }
        break;
      default:
        console.error("Error Occured! type missmatch : in ServicePackageDispatcherComponent! \n " + JSON.stringify(msg));
        break;
    }
  }

  ngOnInit() {}
}
