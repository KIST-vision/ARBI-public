import { NgModule } from '@angular/core';

import {CollapseModule} from 'ngx-bootstrap';
import {CommonModule} from '@angular/common'

import {ServiceDispatcherFileListComponent, ServiceDispatcherFileViewComponent} from '../module/servicedispatcher'
import {ServicePackageDispatcherComponent} from './dispatcher.component'

@NgModule({
  imports: [CollapseModule, CommonModule],
  declarations: [ServiceDispatcherFileListComponent, ServiceDispatcherFileViewComponent, ServicePackageDispatcherComponent],
  providers: [],
  exports:[ServicePackageDispatcherComponent]
})
export class ServicePackageDispatcherModule {

}
