import { Injectable } from '@angular/core';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

import {HubService} from '../communication/hub.service'

@Injectable()
export class ServicePackageDispatcherService {

  private eventInvoke:Subject<string> = new Subject<string>();

  public getEventInvoke():Subject<string>{
    return this.eventInvoke;
  }

  private messages : Observable<any>;
  private subscription: Subscription;

  constructor(private _hub: HubService) {
    this.messages = _hub.subscribeSystemMessage();
    this.subscription = this.messages.subscribe(this.on_next);
    console.log(this.eventInvoke);
  }

  public on_next = (msg:any) => {
    let message;
    if(typeof message == "string"){
      message = JSON.parse(msg);
    } else {
      message = msg;
    }

    if(message.Actor == "initiator" || message.Actor == "Initiator"){
      console.log("Package Dispatcher Message Received");

      this.eventInvoke.next(message);
      // this.parseSystemMessage(message);
    }
  }
}
