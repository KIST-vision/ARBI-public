import { Component } from '@angular/core';
import { Agent } from './base.agent';
import {HubService, SystemMessage} from '../communication/hub.service';
import {KnowledgeManagerService} from './knowledgemanager.service';

@Component({
  selector:'agent-knowledgemanager',
  template: `
    <div fxLayout="row" fxLayoutWrap fxLayoutAlign="space-around">
      <knowledge fxFlex=100 [model]="knowledgeStore"></knowledge>
      <!--<ontology fxFlex=100 [model]="ontology"></ontology>-->
      <inference fxFlex=100 [model]="inference.reverse()"></inference>
      <!--<gt fxFlex=100 [model]="gt"></gt>-->
    </div>
  `
})
export class KnowledgeManagerComponent extends Agent{
  title = 'agent-knowledge-manager';

  private knowledgeStore = [];
  private inference = []
  private ontology = []

  constructor(private know:KnowledgeManagerService){
    super("knowledgemanager");
    this.know.invokeEvent.subscribe(message => {
      let obj = JSON.parse(message);
      this.inference = obj.inference;
      this.ontology = obj.ontology;
      this.knowledgeStore = obj.knowledgeStore;
    })
    this.know.draw();
  }
}
