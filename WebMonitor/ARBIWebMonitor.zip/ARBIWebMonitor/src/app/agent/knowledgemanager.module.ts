import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import {CommonModule} from '@angular/common'
import { FlexLayoutModule } from '@angular/flex-layout';

import {PaginationModule} from 'ngx-bootstrap'

import {Ontology, Inference, GT, KnowledgeComponent} from '../module/knowledgemanager';
import {KnowledgeManagerComponent} from '../agent/knowledgemanager.component'

@NgModule({
  imports: [FormsModule, FlexLayoutModule, CommonModule, PaginationModule],
  declarations: [KnowledgeManagerComponent, Ontology, Inference, GT, KnowledgeComponent],
  exports:[KnowledgeManagerComponent],
  providers: []
})
export class KnowledgeManagerModule { }
