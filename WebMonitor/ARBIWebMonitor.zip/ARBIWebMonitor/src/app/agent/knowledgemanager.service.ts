import { Injectable } from '@angular/core';

import {HubService, SystemMessage} from '../communication/hub.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Injectable()
export class KnowledgeManagerService {
  private knowledgeArray:Array<Ontology>
  private dataManager = {
    push:function(content,action){
      let msg = {
        type:content.msg.QueryType,
        result:content.msg.Result,
        time:content.msg.InferenceTime
      };
      this.inference.push(msg);
      if(action == "QueryProperty"){
        this.knowledge.push(content);
      }
      // type result time
    },
    inference:[],
    ontology:[],
    knowledge:{
      push:function(message){
        let relatedFrom = message.ontology.RelatedFrom;
        let relatedTo = message.ontology.RelatedTo;
        let typeClass = message.ontology.TypeClass;
        let upperClass = message.ontology.UpperClass;
        let type = message.ontology.type;
        let target = message.ontology.Target;

        let ont = new Ontology(target, type, relatedFrom, relatedTo, typeClass, upperClass);
        this.store.push(ont);
      },
      store : [{
          "RelatedFrom": [
            [
              "http://www.arbi.com/ontologies/arbi.owl#hasInnerPoint",
              "http://www.arbi.com/ontologies/arbi_map.owl#OfficeRoom001_InnerPoint001"
            ]
          ],
          "RelatedTo": [
           [
             "http://www.arbi.com/ontologies/arbi.owl#workPlace",
             "http://www.arbi.com/ontologies/GuideService.owl#ResearchDepartment001"
           ]
         ],
         "TypeClass": "http://knowrob.org/kb/knowrob.owl#OfficeRoom",
         "UpperClass": "http://knowrob.org/kb/knowrob.owl#RoomInAConstruction",
         "Target":"http://www.arbi.com/ontologies/arbi_map.owl#place001"
        }
      ]
    },
    log:[],
    init: function(inference,ontology, log){

      this.inference = inference;
      this.ontology = ontology;
      this.log = log;
    },
    save:function(){
      localStorage.setItem("knowledgemanager",JSON.stringify(this.toObject()));
    },
    toObject: function(){
      return {

        "inference":this.inference,
        "ontology":this.ontology,
        "log":this.log,
        "knowledgeStore":this.knowledge.store
      }
    }
  }
  public invokeEvent = new Subject<string>();

  private messages : Observable<SystemMessage>;
  private subscription: Subscription;

  public draw(){
    this.invokeEvent.next(JSON.stringify(this.dataManager.toObject()))
  }

  constructor(private _hub:HubService) {
    this.messages = _hub.subscribeSystemMessage()
    this.subscription = this.messages.subscribe(this.on_next)

    // let storage_str = localStorage.getItem("knowledgemanager");
    // if(storage_str == null || storage_str == "undefined") return;
    //
    // let storage = JSON.parse(localStorage.getItem("knowledgemanager"));
    // this.dataManager.init(storage.inference, storage.ontology, storage.log);
  }

  public on_next = (message: any) => {
    let msg;

    if(typeof message != "object"){
      msg = JSON.parse(message);
    } else {
      msg = message;
    }
    // console.log(msg.Actor);

    if(msg.Actor == "knowledgeManager" || msg.Actor =="null"){
      console.log("on knowledgeservice message incomming!");
      this.parseSystemMessage(msg);

    }

    // this._invokeEvent.next(this.agentConversationLogManager.toString());
    // this.agentConversationLogManager.save();
    // this.dataManager.save();
    this.draw();
  }

  private parseSystemMessage(message:any){
    console.log("KM PARSING");
    let mobj = {content : message.Content, time : message.Time, type:message.Type, action:message.Action}
    let content = JSON.parse(mobj.content.replace(/&quot;/g,'"'));;
    switch(mobj.type){
      case "INFERENCE":
        this.dataManager.inference.push(content);
        break;
      case "UPDATEOWL":
        this.dataManager.ontology = content;
        break;
      case "KNOWLEDGE":
        this.dataManager.knowledge.push(content);
        //TODO
        break;
      case "QueryType":
        this.dataManager.push(content,mobj.action);
        break;
      default:
        console.log("Error in KM Parse code");
        console.log(message);
        break;
    }
  }
}

class Ontology {
  public type:number;
  public RelatedFrom:Array<Array<string>>;
  public RelatedTo:Array<Array<string>>;
  public TypeClass:string;
  public UpperClass:string;
  public Target:string;

  constructor(target:string, type:number, RelatedFrom:Array<Array<string>>, RelatedTo:Array<Array<string>>, TypeClass:string, UpperClass:string){
    this.Target = target;
    this.type = type;
    this.RelatedFrom = RelatedFrom;
    this.RelatedTo = RelatedTo;
    this.TypeClass = TypeClass;
    this.UpperClass = UpperClass;
  }
}
