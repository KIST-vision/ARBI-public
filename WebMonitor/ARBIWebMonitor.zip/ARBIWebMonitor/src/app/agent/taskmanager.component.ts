import { Component } from '@angular/core';
import { Agent } from './base.agent';
import {HubService, SystemMessage} from '../communication/hub.service';
import {TaskManagerService} from './taskmanager.service';

@Component({
  selector:'agent-taskmanager',
  template: `
    <div fxLayout="row" fxLayoutWrap fxLayoutAlign="space-around">
      <intention-current fxFlex=25>{{intention.model.length}}</intention-current>
      <intention-complete fxFlex=25>{{intention.completed}}</intention-complete>
      <worldmodel-access fxFlex=25>{{worldModel.log.length}}</worldmodel-access>
      <worldmodel-current fxFlex=25>{{worldModel.model.length}}</worldmodel-current>
      <intention-log fxFlex=100 [model]="intention.log.reverse()"></intention-log>
      <worldmodel-log fxFlex=100 [model]="worldModel.log.reverse()"></worldmodel-log>
      <intention-structure fxFlex=50 [model]="intention.model"></intention-structure>
      <worldmodel-structure fxFlex=50 [model]="worldModel.model"></worldmodel-structure>
    </div>
  `
})
export class TaskManagerComponent extends Agent{
  title = 'agent-task-manager';

  private intention = {
    model:[],
    log:[],
    completed:0
  };
  private worldModel = {
    model:[],
    log:[]
  }

  constructor(private task:TaskManagerService){
    super("taskmanager");
    this.task.invokeEvent.subscribe(msg => {
      let message:any = msg;
      switch(message.Type){
        case "WorldModel":
          this.worldModel.log.push({"time":message.Time,"action":message.Action,"content":message.Content});
          switch(message.Action){
            case "Assert":
            if(this.worldModel.model.indexOf(message.Content) < 0){
              this.worldModel.model.push(message.Content);
            }
              break;
            case "Retract":

              break;
          }
          break;
        case "Goal":
          this.intention.log.push({"time":message.Time,"action":message.Action,"content":message.Content});
          switch(message.Action){
            case "New":
              if (this.intention.model.indexOf(message.Content) <0) {
                  this.intention.model.push(message.Content);
              }
            break;
            case "Unpost":
              let index=this.intention.model.indexOf(message.Content);
                if(!(index < 0)){
                this.intention.model.splice(index,1);
                this.intention.completed++;
              }
            break;
          }
          break;
        }

      // this.intention = obj.intention;
      // this.worldModel = obj.worldmodel;
    })
    task.draw();
  }
}
