import { NgModule } from '@angular/core'

import {CommonModule} from '@angular/common'

import { IntentionCurrent } from '../module/taskmanager/status.intention.current'
import { IntentionComplete } from '../module/taskmanager/status.intention.complete'
import { IntentionStructure } from '../module/taskmanager/structure.intention'
import { WorldModelAccess } from '../module/taskmanager/status.worldmodel.access'
import { WorldModelCurrent } from '../module/taskmanager/status.worldmodel.current'
import {WorldModelStructure} from '../module/taskmanager/structure.worldmodel'
import { IntentionLog} from '../module/taskmanager/log.intention'
import {WorldModelLog} from '../module/taskmanager/log.worldmodel'

import {BaseMonitorModule} from '../module/base.module'

import { FlexLayoutModule } from '@angular/flex-layout';

import { TaskManagerComponent } from './taskmanager.component'


@NgModule({
  imports: [FlexLayoutModule, CommonModule],
  declarations: [IntentionCurrent, IntentionComplete, IntentionStructure, WorldModelAccess, WorldModelCurrent, BaseMonitorModule, TaskManagerComponent, WorldModelStructure, IntentionLog, WorldModelLog],
  exports: [TaskManagerComponent]
})
export class TaskManagerModule {}
