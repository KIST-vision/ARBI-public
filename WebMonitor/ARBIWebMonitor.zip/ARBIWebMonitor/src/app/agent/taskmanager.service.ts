import { Injectable, OnDestroy } from '@angular/core';
import {HubService, SystemMessage} from '../communication/hub.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Injectable()
export class TaskManagerService implements OnDestroy {
  private dataManager = {
    intention : {
      model : [],
      completed : 0,
      log : []
    },
    worldmodel : {
      model:[],
      log:[]
    },
    save: function(){
      localStorage.setItem("taskmanager",JSON.stringify(this.toObject()));
    },
    toObject: function(){
      return {
        intention: this.intention,
        worldmodel: this.worldmodel
      }
    },
    init : function(intention, worldmodel){
      this.intention = intention;
      this.worldmodel = worldmodel;
    }
  }

  private messages : Observable<SystemMessage>;
  private subscription: Subscription;

  public invokeEvent = new Subject<string>();

  public draw(){
    this.invokeEvent.next(JSON.stringify(
      {
        intention:this.dataManager.intention,
        worldmodel:this.dataManager.worldmodel
      }
    ))
  }

  constructor( private _hub: HubService) {
    this.messages = _hub.subscribeSystemMessage()
    this.subscription = this.messages.subscribe(this.on_next)

    // let storage_str = localStorage.getItem("taskmanager");
    // if(storage_str == null || storage_str == "undefined") return;
    //
    // let storage = JSON.parse(localStorage.getItem("taskmanager"));
    // this.dataManager.init(storage.intention, storage.worldmodel);

  }

  public on_next = (msg: any) => {
    let message;
    if(typeof message == "string"){
      message = JSON.parse(msg);
    } else {
      message = msg;
    }


    if(message.Actor == "TaskManager" || message.Actor == "taskManager"){
      console.log("TaskManager onNEXT")
      this.invokeEvent.next(message);
      // this.parseSystemMessage(message);
    }
    // this._invokeEvent.next(this.agentConversationLogManager.toString());
    // this.agentConversationLogManager.save();
    // this.dataManager.save();
    // this.draw();
  }

  private parseSystemMessage(message : SystemMessage){
    console.log("TM PARSING");
    switch(message.Type){
      case "WorldModel":
        this.dataManager.worldmodel.log.push({"time":message.Time,"action":message.Action,"content":message.Content});
        switch(message.Action){
          case "Assert":
          if(this.dataManager.worldmodel.model.indexOf(message.Content) < 0){
            this.dataManager.worldmodel.model.push(message.Content);
          }
            break;
          case "Retract":

            break;
        }
        break;
      case "Goal":
        this.dataManager.intention.log.push({"time":message.Time,"action":message.Action,"content":message.Content});
        switch(message.Action){
          case "New":
            if (this.dataManager.intention.model.indexOf(message.Content) <0) {
                this.dataManager.intention.model.push(message.Content);
            }
          break;
          case "Unpost":
            let index=this.dataManager.intention.model.indexOf(message.Content);
              if(!(index < 0)){
              this.dataManager.intention.model.splice(index,1);
              this.dataManager.intention.completed++;
            }
          break;
        }
        break;
      }
  }

  ngOnDestroy(){
    console.log("on destroy");
    this.dataManager.save();
  }
}
