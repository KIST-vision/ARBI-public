import { Component, OnInit } from '@angular/core';
import {STOMPService} from './communication/stomp.service';
import {SSEService} from './communication/sse.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.styl']
})
export class AppComponent implements OnInit {
  constructor(private _stompService : STOMPService, private _sseService : SSEService){

  }
  title = 'app';
  public ngOnInit(){
    // this._stompService.subscribe();
    // this._stompService.init();

    this._sseService.subscribe();
    this._sseService.init();
  }
}
