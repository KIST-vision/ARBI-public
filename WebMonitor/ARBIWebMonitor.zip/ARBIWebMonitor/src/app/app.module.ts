import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';

import { FlexLayoutModule } from '@angular/flex-layout';

import {StompConfig, StompService} from '@stomp/ng2-stompjs';
import {STOMPService} from './communication/stomp.service';
import {SSEService} from './communication/sse.service';

import {TaskManagerModule} from './agent/taskmanager.module';
import { TaskManagerComponent } from './agent/taskmanager.component';
import {KnowledgeManagerModule} from './agent/knowledgemanager.module'
import {KnowledgeManagerComponent} from './agent/knowledgemanager.component'
import { ConversationComponent } from './agent/conversation.component';
import {ConversationService} from './agent/conversation.service';
import {TaskManagerService} from './agent/taskmanager.service';
import {KnowledgeManagerService} from './agent/knowledgemanager.service';
import {ContextManagerService} from './agent/contextmanager.service';
import {ContextManagerModule} from './agent/contextmanager.module';
import {ContextManagerComponent} from './agent/contextmanager.component';
import {ServicePackageDispatcherModule} from './agent/dispatcher.module';
import {ServicePackageDispatcherService} from './agent/dispatcher.service';

import {CollapseModule, PaginationModule, TabsModule} from 'ngx-bootstrap';

import {HubService} from './communication/hub.service'


// const APP_ROUTES: Routes = [
//   {path: '', redirectTo: '/agent/taskmanager', pathMatch:'full'},
//   {path: 'agent/taskmanager', component:TaskManagerComponent},
//   {path: 'agent/conversation', component:ConversationComponent},
//   {path: 'agent/knowledgemanager', component:KnowledgeManagerComponent},
//   {path: 'agent/contextmanager', component:ContextManagerComponent}
// ]

const stompConfig: StompConfig = {
  url: 'ws://127.0.0.1:61614',
  headers:{
    login:'guest',
    password:'guest'
  },
  heartbeat_in: 0,
  heartbeat_out: 20000,

  reconnect_delay : 5000,
  debug: true
};

@NgModule({
  declarations: [
    AppComponent,
    ConversationComponent
  ],
  imports: [
    CollapseModule.forRoot(),
    PaginationModule.forRoot(),
    TabsModule.forRoot(),
    BrowserModule,
    FormsModule,
    FlexLayoutModule,
    TaskManagerModule,
    KnowledgeManagerModule,
    ContextManagerModule,
    ServicePackageDispatcherModule
    // RouterModule.forRoot(APP_ROUTES),
  ],
  providers: [StompService,
    {
      provide: StompConfig,
      useValue: stompConfig
    }, HubService, STOMPService, SSEService
  ,ConversationService,
  TaskManagerService,
  KnowledgeManagerService,
  ContextManagerService,
  ServicePackageDispatcherService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
