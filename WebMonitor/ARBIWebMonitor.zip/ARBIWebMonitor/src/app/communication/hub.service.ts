import {Injectable} from '@angular/core'

import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class HubService{
  private agentMessageSubject = new Subject<AgentMessage>();
  private systemMessageSubject = new Subject<SystemMessage>();
  private ltmMessageSubject = new Subject<LTMMessage>();

  public pushSystemMessage(message:any) : boolean{
    let mes = message;
    if(typeof message == "string"){
      mes = JSON.parse(message);
    }
    this.systemMessageSubject.next(mes);
    console.log("systemmessage incomming!" + JSON.stringify(mes) );
    console.log(mes.Actor)
    return true;
  }
  public subscribeSystemMessage():Observable<SystemMessage>{
    return this.systemMessageSubject.asObservable();
  }
  public pushAgentMessage(message:AgentMessage):boolean{
    console.log("here is hub service")
    console.log(message);
    this.agentMessageSubject.next(message);
    return true;
  }
  public subscribeAgentMessage():Observable<AgentMessage>{
    return this.agentMessageSubject.asObservable();
  }
  public pushLTMMessage(message:LTMMessage) : boolean{
    this.ltmMessageSubject.next(message);
    return true;
  }
  public subscribeLTMMessage():Observable<LTMMessage>{
    return this.ltmMessageSubject.asObservable();
  }
}

export class LTMMessage {
  private _client:string;
  private _action:string;
  private _content:string;
  constructor(client:string,action:string,content:string){
    this._client = client;
    this._action = action;
    this._content = content;
  }

  get Client():string {
    return this._client;
  }
  get Action():string{
    return this._action;
  }
  get Content():string{
    return this._content;
  }
  get jsonObject(){
    return {
      "Client": this._client,
      "Action": this._action,
      "Content": this._content
    }
  }
}

export class AgentMessage {
  /*
    data example here
    {
    	"Receiver" : "agent://www.arbi.com/TaskManager",
    	"Sender" : "agent://www.arbi.com/ServicePackageDispatcher",
    	"Action" : "QUERY",
    	"Content" : "(IsManagerAvailable)"
    }
  */
  private _receiver:string;
  private _sender:string;
  private _action:string;
  private _content:string;

  constructor(receiver:string, sender:string, action:string, content:string){
    this._receiver = receiver;
    this._sender = sender;
    this._action = action;
    this._content = content;
  }

  get Receiver():string {
    return this._receiver;
  }
  get Sender():string{
    return this._sender;
  }
  get Action():string{
    return this._action;
  }
  get Content():string{
    return this._content;
  }

  get jsonObject() {
    return {
      "Receiver":this._receiver,
      "Sender":this._sender,
      "Action":this._action,
      "Content":this._content
    }
  }
}

export class SystemMessage {
  /*
    data example here
    {
    	"Actor":"taskManager",
    	"Time" : "651321654231",
    	"Action" : "Assert",
    	"Content" : "testPlan",
    	"Type" : "WorldModel"
    }
  */
  public Actor : string;
  public Time : number;
  public Action : string;
  public Type : string;
  public Content : string;

  constructor(actor: string, time: number, action: string, type: string, content: string){
    this.Actor = actor;
    this.Time = time;
    this.Action = action;
    this.Type = type;
    this.Content = content;
  }

  get jsonObject(){
    return JSON.parse(`{
      "Actor":this.Actor,
      "Time":this.Time,
      "Action":this.Action,
      "Type":this.Type,
      "Content":this.Content,
    }`)
  }

}
