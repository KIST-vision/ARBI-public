import { Injectable, NgZone } from '@angular/core';

import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';

import {Subscription} from 'rxjs/Subscription';

import {HubService, AgentMessage, LTMMessage, SystemMessage} from './hub.service'

const EventSource: any = window['EventSource'];
declare var $:any

@Injectable()
export class SSEService {
  private source:any;
  private bigDataSource:any;
  private subscribed:boolean = false;
  private bigSubscribed:boolean = false;
  constructor(private hub: HubService, private zone: NgZone) {}

  public subscribe(){
    this.source = new EventSource("http://127.0.0.1:9371/stream/origin");
    // this.bigDataSource = new EventSource("http://127.0.0.1:9371/stream/big");
    this.subscribed = true;
  }

  public testFunction(){
    console.log("test function fired");
  }

  public init(){
    if(!this.subscribed){
      console.log("need to subscribe first.");
      return;
    }

    // this.bigDataSource.addEventListener('packageDispatch', (event) => {
    //   let mesArray = event.data.split("/SPLIT/");
    //
    //   let metadata = mesArray[0];
    //   let content = mesArray[1];
    //   let metaJSON = JSON.parse(metadata);
    //
    //   metaJSON.Content = content;
    //
    //   this.hub.pushSystemMessage(metaJSON)
    // })
    //
    // this.bigDataSource.onmessage = (event) => {
    //   console.log("on HUGE message!");
    //   console.log(event);
    //
    //   let mesArray = event.data.split("/SPLIT/");
    //
    //   let metadata = mesArray[0];
    //   let content = mesArray[1];
    //   let metaJSON = JSON.parse(metadata);
    // }

    this.source.onmessage = (event) => {
      console.log("on message!");
      console.log(event);

      let data = JSON.parse(event.data);
      if(data.AgentMessageStore){
        for(var mes of data.AgentMessageStore){
          let m = new AgentMessage(mes.Receiver,mes.Sender,mes.Action,mes.Content);
          console.log(m)
          this.hub.pushAgentMessage(m);
        }
      }
      if(data.LTMMessageStore){
        for(var mes of data.LTMMessageStore){
          this.hub.pushLTMMessage(mes);
        }
      }
      if(data.SystemMessageStore){
        for(var mes of data.SystemMessageStore){
          this.hub.pushSystemMessage(mes);
        }
      }
      data.SystemMessageStore;

    };

    this.source.onopen = function(event){
      // console.log("Event Start!");
    }

    this.source.addEventListener('agentMessage', (event) => {
      // console.log("Agent Message Comming");
      let mes;
      if(typeof event.data == "string") {
        mes = JSON.parse(event.data);
      } else {
        mes = event.data;
      }
      let m = new AgentMessage(mes.Receiver,mes.Sender,mes.Action,mes.Content);
      // console.log(m)
      this.hub.pushAgentMessage(m);
    })

    this.source.addEventListener('LTMMessage', (event) => {
      // console.log("LTM Message Comming");
      var data;
      if(typeof event.data == "string") {
        data = JSON.parse(event.data);
      } else {
        data = event.data;
      }
      this.hub.pushLTMMessage(data);
      // dataManager.LTMMessageManager.push(data);
    })

    this.source.addEventListener('systemMessage', (event) => {
      // console.log("this is systemMessage");
      // console.log(event.data);

      this.hub.pushSystemMessage(event.data);
      // dataManager.SystemMessageManager.push(event.data);
    })

    function clearData(data){
      var d = $("<textarea/>").html(data).text();
      d = d.replace(/(LINEBREAK)/g, '\n').replace(/(TAB)/g,'\t').replace(/(CARRAGERETURN)/g,'\r').replace(/(BACKSLASH)/g, "\\");
      return d;
    }
  }
}
