import {Injectable} from '@angular/core';

import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Observable';

import {Subscription} from 'rxjs/Subscription';

import {Message} from '@stomp/stompjs';
import {StompService} from '@stomp/ng2-stompjs';

import {HubService, AgentMessage, LTMMessage, SystemMessage} from './hub.service'


@Injectable()
export class STOMPService {
  // public static MONITOR_ID = "WEB_MONITOR#" + Math.floor(Math.random()*10000+1)
  //
  // private subscription: Subscription;
  // public messages: Observable<Message>;
  //
  // public subscribed: boolean;
  // constructor(private hub: HubService, private _stomp: StompService){
  // console.log(this.hub) }
  //
  // public subscribe(){
  //   if(this.subscribed) return;
  //
  //   this.messages = this._stomp.subscribe('/queue/' + STOMPService.MONITOR_ID);
  //   this.subscription = this.messages.subscribe(this.on_next);
  //   this.subscribed = true;
  // }
  //
  // public init(){
  //   if(!this.subscribed) return;
  //
  //   this._stomp.publish('/queue/interactionManager',`{
  //     "ID":'+STOMPService.MONITOR_ID+',
  //     "Action":"Create Monitor",
  //     "Protocol":"WebSocket",
  //     "Filter":[
  //       {"LogType":"MessageLog", "Type":"AgentMessage","Action":"Request", "Flag":"true"},
  //   		{"LogType":"MessageLog", "Type":"AgentMessage","Action":"Response", "Flag":"true"},
  //   		{"LogType":"MessageLog", "Type":"AgentMessage","Action":"Query", "Flag":"true"},
  //   		{"LogType":"MessageLog", "Type":"LTMMessage","Action" :"Result","Flag":"true"}
  //     ]
  //   }`);
  // }
  //
  //
  // public on_next = (message: Message) => {
  //   let mes = JSON.parse(message.body);
  //   console.log(mes);
  //   switch(mes.Logtype){
  //     case "MessageLog":
  //       if(mes.Type == "AgentMessage") this.hub.pushAgentMessage(new AgentMessage(mes.Receiver,mes.Sender,mes.Action,mes.Content));
  //       if(mes.Type == "LTMMessage") this.hub.pushLTMMessage(new LTMMessage(mes.Client, mes.Action, mes.Content));
  //     break;
  //     case "SystemLog":
  //       this.hub.pushSystemMessage(new SystemMessage(mes.Actor, Number(mes.Time), mes.Action, mes.Type, mes.Content))
  //     break;
  //     default:
  //     console.log("something is wrong! in STOMPService");
  //     console.log(mes);
  //     }
  // }
}
