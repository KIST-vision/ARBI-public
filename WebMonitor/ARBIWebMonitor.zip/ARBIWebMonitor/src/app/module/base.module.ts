import { Component, Input } from '@angular/core'

@Component({
  selector:"base-module",
  template: `
    <!--<div class="module">
      <div fxLayout="column">
        <div fxFlex="25px">
          <div fxLayout="row" fxLayoutAlign="end">
            <div fxFlex="100px">
              <input type="checkbox" value="Enable"> enabled
            </div>
          </div>
        </div>
        <div fxFlex="190px">
          <ng-content></ng-content>
        </div>
      </div>
    </div>-->
    <ng-content></ng-content>
  `
})
export class BaseMonitorModule {
  @Input() mwidth : number;
}

export class MonitorModule {
  protected _moduleSubscribeMessage : string;
  public enabled : boolean = true;
  get moduleSubscribeMessage() : string{
    return this._moduleSubscribeMessage
  }
  set moduleSubscribeMessage(value:string) {
    this._moduleSubscribeMessage = value;
  }
  constructor(){}
}
