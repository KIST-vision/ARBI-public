import { Component, OnInit, Input, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
// import {CHART_DIRECTIVES} from 'ng2-charts/ng2-charts';

@Component({
  selector: 'common-graph',
  template: `
    <div class="panel panel-default">
      <!--<div *ngIf="title" class="panel-heading">
        {{title}}
      </div>-->
      <div class="panel-body">
        <div class="row">
          <div class="col-sm-12">
            <div style="display:block">
              <canvas baseChart
                [datasets]="d1"
                [labels]="l1"
                [options]="lineChartOptions"
                [colors]="lineChartColors"
                [legend]="leg"
                (chartClick)="randomize()"
                chartType="bar"></canvas>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12"></div>
        </div>
      </div>
    </div>
  `,
})
export class GraphComponent implements OnInit {
  @Input() title;
  private _gm:GraphicModel;
  private leg = false;
  @Input() set model(value:GraphicModel){
    this._gm = value;
    if(value.chartData[0].data.length>5){
      let length = value.chartData[0].data.length;
      this.d1[0].data = value.chartData[0].data.slice(length-6, length-1);
      this.l1 = value.chartLabel.slice(length-6, length-1);
    } else {
      this.d1[0].data = value.chartData[0].data;
      this.l1 = value.chartLabel;
    }


    if(typeof this.chart.chart != "undefined"){
      this.chart.chart.update();
    }
  };
  get model(){
    return this._gm;
  }

  @ViewChild(BaseChartDirective) public chart: BaseChartDirective;

  private d1 = [{"labels":"x","data":[0,2,3,4,5]}];
  private l1 = ["x","x1","x2","x3","x4"];

  private randomize(){
    this.d1[0]["data"].push(Math.floor(Math.random()*20));
    this.l1.push("x" + Math.floor(Math.random()*20));
    this.chart.chart.update();
    // let data = this.d1;
    // let label = this.l1;
    // data[0]["data"].push(3);
    // label.push("x" + Math.floor(Math.random()*20));

    // data[0]["data"].pop();
    // label.pop();
    //
    // console.log("what" + JSON.stringify(this.d1) + '\n' + JSON.stringify(this.l1));
    //
    // this.d1 = this.d1.slice();
    // this.l1 = JSON.parse(JSON.stringify(label));
  }

  public lineChartOptions:any = {
    responsive: true,
    scales:{
      yAxes:[{
        ticks:{
          beginAtZero:true
        }
      }]
    }
  }
  public lineChartColors:Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ]
  public lineChartType:string = 'line';

  constructor() {  }

  ngOnInit() {
    // console.log("CommonGraphModel = " + JSON.stringify(this.model))
  }

  ngOnChanges(change:SimpleChanges){
    // console.log("Model Change:"+JSON.stringify(change));
    if(typeof this.chart.chart != "undefined"){
      // console.log("let's update chart!");
      this.chart.chart.update();
    }

  }
}

@Component({
  selector: 'doughnut-graph',
  template: `
    <div class="panel panel-default">
      <div *ngIf="title" class="panel-heading">
        {{title}}
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-sm-12">
            <div style="display:block">
              <canvas baseChart
                [datasets]="d1"
                [labels]="l1"
                legend="false"
                chartType="doughnut"></canvas>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12"></div>
        </div>
      </div>
    </div>
  `,
})
export class DoughnutGraphComponent implements OnInit {
  @Input() title;
  private _gm:GraphicModel;
  private d1 = [{"labels":"x","data":[75, 25]}];
  private l1 = ["used","free"];
  @ViewChild(BaseChartDirective) public chart: BaseChartDirective;
  @Input() set model(value:GraphicModel){
    this._gm = value;

    this.d1[0].data = value.chartData[0].data;
    this.l1 = value.chartLabel;

    if(typeof this.chart.chart != "undefined"){
      this.chart.chart.update();
    }
  };
  get model(){
    return this._gm;
  }

  constructor() {  }

  ngOnInit() {
    console.log(this.model)
  }
}

export class GraphicModel {
  public chartData:Array<any>
  public chartLabel:Array<string>;
  constructor(_cd:Array<any>, _cl:Array<string>){
    this.chartData = _cd;
    this.chartLabel = _cl;
  }
  public asObj = function(){
    var data = [];
    return {"data" : this.chartData[0].data};
  }
}
