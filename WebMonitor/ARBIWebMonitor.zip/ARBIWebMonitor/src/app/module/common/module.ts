import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {GraphComponent, DoughnutGraphComponent, GraphicModel} from './graph.component';
import {StatusComponent} from './status.component';
import {ChartsModule} from 'ng2-charts/ng2-charts';

@NgModule({
  imports: [ChartsModule, CommonModule],
  declarations: [GraphComponent, StatusComponent, DoughnutGraphComponent],
  exports:[GraphComponent, StatusComponent, DoughnutGraphComponent],
  providers: []
})
export class CommonComponentModule { }
