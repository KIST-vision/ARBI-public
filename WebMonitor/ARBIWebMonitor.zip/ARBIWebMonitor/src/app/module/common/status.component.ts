import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'common-status',
  template: `
    <div><div class="panel panel-default">
      <div class="panel-heading">{{title}}</div>
      <div class="panel-body">{{content}}</div>
    </div></div>`,
})
export class StatusComponent implements OnInit {
  @Input() title;
  @Input() content;
  constructor() {  }

  ngOnInit() {}
}
