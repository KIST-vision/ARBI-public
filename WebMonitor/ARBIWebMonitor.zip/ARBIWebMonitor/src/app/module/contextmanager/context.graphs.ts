import { Component, OnInit, Input } from '@angular/core';
import { GraphicModel } from '../common/graph.component'

@Component({
  selector: 'context-graphs',
  template:`
  <div class="panel panel-default" fxFlex=100>
    <div class="panel-heading">
      Context Knowledge
    </div>
    <div class="panel-body" fxLayout=column>
      <div fxFlex=50><common-graph [model]="knowledgeGraphicModel"></common-graph></div>
      <div fxFlex=50 fxLayout=row>
        <div fxFlex=50 style="text-align:left">
          <!--<button class="btn btn-default">Data Explorer</button>-->
        </div>
        <div fxFlex=50 style="text-align:right">{{knowledgeCount}} M</div>
      </div>
    </div>
  </div>
  <!--<div fxFlex=40 class="panel panel-default">
    <div class="panel-heading">
      Context Reasoning
    </div>
    <div class="panel-body" fxLayout=column>
      <common-graph [model]="reasoningGraphicModel"></common-graph>
      <div fxFlex=50 fxLayout=row>
      <div fxFlex=50 style="text-align:left">

      </div>
      <div fxFlex=50 style="text-align:right">{{reasoningCount}} M</div>
      </div>
    </div>
  </div>-->

  `
})
export class ContextGraphComponent implements OnInit {
  @Input() knowledgeCount;
  @Input() reasoningCount;
  @Input() knowledgeGraphicModel:GraphicModel;
  @Input() reasoningGraphicModel:GraphicModel;
  constructor() {  }

  ngOnInit() {
    console.log(this.knowledgeGraphicModel);
  }
}
