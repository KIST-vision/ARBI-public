import { Component, OnInit, Input } from '@angular/core';
import { GraphicModel } from '../common/graph.component'

@Component({
  selector: 'context-service',
  template: `
    <div class="panel panel-default">

    <div class="panel-heading">latest perceptions</div>
    <div class="panel-body">
    <div class="panel panel-default">

    <div class="panel-heading">User</div>
    <div class="panel-body">{{perception.user}}</div>

    </div>
    <div class="panel panel-default">

    <div class="panel-heading">Object</div>
    <div class="panel-body">{{perception.object}}</div>

    </div>
    <div class="panel panel-default">

    <div class="panel-heading">Voice</div>
    <div class="panel-body">{{perception.voice}}</div>

    </div>
    <div class="panel panel-default">

    <div class="panel-heading">Latest Robot Location</div>
    <div class="panel-body">{{perception.location}}</div>

    </div>
    </div>


  `,
})
export class ContextServiceComponent implements OnInit {
  private isContextCollapsed:boolean = true;

  public collapsed(event:any):void {
    console.log(event);
  }

  public expanded(event:any):void {
    console.log(event);
  }
  @Input() perception;
  @Input() query;
  @Input() contextService;
  constructor() {  }

  ngOnInit() {

  }
}
