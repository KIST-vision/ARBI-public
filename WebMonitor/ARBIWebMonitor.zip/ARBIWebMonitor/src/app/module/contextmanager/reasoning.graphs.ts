import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'reasoning-graphs',
  template: `

    <common-graph fxFlex=45 [model]="lowlevel" title="Low Level Graph"></common-graph>
    <common-graph fxFlex=45 [model]="highlevel" title="High Level Graph"></common-graph>

  `,
})
export class ReasoningGraphsComponent implements OnInit {
  @Input() lowlevel:any;
  @Input() highlevel:any;
  constructor() {  }

  ngOnInit() {}
}
