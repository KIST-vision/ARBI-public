import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'robot-graphs',
  template: `
    <div fxLayout="column" fxFlex=100>
      <doughnut-graph [model]="availableBattery" title="Available Battery"></doughnut-graph>
      <div>Current Status : {{isCharging}}</div>
    <div>


  `,
})
export class RobotGraphsComponent implements OnInit {
  @Input() isCharging:string = "Not Charging";
  @Input() availableBattery:any;

  @Input() title:string;
  constructor() {  }

  ngOnInit() {}
}
