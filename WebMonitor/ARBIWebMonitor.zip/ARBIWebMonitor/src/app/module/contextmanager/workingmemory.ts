import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'workingmemory',
  template: `
  <div fxLayoutWrap fxLayoutAlign="space-between">
  <div fxFlex=100><h3>Current Working Memory</h3></div>
  <common-status fxFlex=30 title="WorldModel Monitor" [content]="monitor"></common-status>
  <common-status fxFlex=30 title="Perception Subscription" [content]="perception"></common-status>
  <common-status fxFlex=30 title="Context Knowledge" [content]="triple"></common-status>
  </div>
  `,
})
export class WorkingMemory implements OnInit {
  @Input() perception;
  @Input() monitor;
  @Input() triple;

  constructor() {  }

  ngOnInit() {
    console.log(this.perception)
  }
}
