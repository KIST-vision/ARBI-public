export {GT} from './gt';
export {Inference} from './inference';
export {Ontology} from './ontology';
export {KnowledgeComponent} from './knowledge';
