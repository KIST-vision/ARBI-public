import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'inference',
  template: `<div class="panel panel-default">
  <div class="panel-heading">Inference Log</div>
    <table class="table table-fixed">
      <thead><tr>
        <th class="col-xs-1">#</th>
        <th class="col-xs-3">Type</th>
        <th class="col-xs-5">Result</th>
        <th class="col-xs-3">Inference Time</th>
      </tr></thead>
      <tbody>
        <tr *ngFor="let val of model; let i = index">
          <td class="col-xs-1">{{i}}</td>
          <td class="col-xs-3">{{val.type}}</td>
          <td class="col-xs-5">{{val.result}}</td>
          <td class="col-xs-3">{{val.time}}</td>
        </tr>
      </tbody>
    </table>
  </div>`,
  styleUrls:['../../css/table-fixed.css']
})
export class Inference implements OnInit {
  @Input() model;
  constructor() {  }

  ngOnInit() {}
}
