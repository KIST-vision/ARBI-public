import { Component, OnInit, OnChanges, SimpleChanges, Input } from '@angular/core';

import {Network, DataSet, Node, Edge, IdType} from 'vis';

@Component({
  selector: 'knowledge',
  template: `
  <div>
    <div class="panel panel-default">
      <div class="panel-heading">Current Shared Knowledge Graph</div>
      <div class="panel-body">
        <div>
          <div fxFlex=50><h4>related To</h4><div id="relatedTo"></div></div>
          <div fxFlex=50><h4>related From</h4><div id="relatedFrom"></div></div>

        </div>

      </div>
      <div class="panel-footer" *ngIf="model.length != 0">
        <pagination [totalItems]="model.length" (pageChanged)="pageChanged($event)" itemsPerPage=1></pagination>
      </div>
    </div>

  </div>
  `,
  styles:[`#relatedTo, #relatedFrom {
    height:300px;
  }`]
})
export class KnowledgeComponent implements OnInit {

  private relatedTo = {
    nodes:new DataSet(),
    edges:new DataSet(),
    network:{}
  }
  private relatedFrom = {
    nodes:new DataSet(),
    edges:new DataSet(),
    network:{}
  }
  public nodes: Node;
  public edges: Edge;
  public network: Network;

  private knowledgeStore = [];

  @Input() model:any;

  ngOnChanges(changes:SimpleChanges){
    // console.log(changes);
  }

  public pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log(this.model);

    this.visualizeOntology(this.model[event.page-1]);
  }

  private visualizeOntology(value){

    this.relatedFrom.nodes.clear();
    this.relatedFrom.edges.clear();

    this.relatedTo.nodes.clear();
    this.relatedTo.edges.clear();

    console.log(value);

    let data = value;
    let subject = data.Target;

    this.relatedTo.nodes.add({"id":subject, "label":subject});
    this.relatedFrom.nodes.add({"id":subject, "label":subject});

    let type = data.TypeClass;
    let upper = data.UpperClass;

    this.relatedTo.nodes.add({"id":type,"label":type,"color":"red"})
    this.relatedTo.edges.add({"from":subject,"to":type,"label":"TypeClass","color":{"color":"red"}})


    this.relatedFrom.nodes.add({"id":type,"label":type,"color":"red"})
    this.relatedFrom.edges.add({"from":subject,"to":type,"label":"TypeClass","color":{"color":"red"}})


    if(upper != undefined){
      this.relatedTo.nodes.add({"id":upper,"label":upper,"color":"lightgreen"})
      this.relatedTo.edges.add({"from":subject,"to":upper,"label":"UpperClass", "color":{"color":"green"}})

      this.relatedFrom.nodes.add({"id":upper,"label":upper,"color":"lightgreen"})
      this.relatedFrom.edges.add({"from":subject,"to":upper,"label":"UpperClass", "color":{"color":"green"}})

    }



    for(let triple of data.RelatedFrom){
      let verb = triple[0];
      let object = triple[1];

      let node = {"id":object, "label":object};
      let edge = {"from":object, "to":subject, "label":verb}

      try{
        this.relatedFrom.nodes.add(node);
      }catch(e){

      }
      try{
        this.relatedFrom.edges.add(edge);
      }catch(e){

      }
    }

    for(let triple of data.RelatedTo){
      let verb = triple[0];
      let object = triple[1];

      let node = {"id":object, "label":object};
      let edge = {"from":object, "to":subject, "label":verb}

      try{
        console.log("node = " + JSON.stringify(node))
        this.relatedTo.nodes.add(node);
      }catch(e){

      }
      try{
        console.log("edge = " + JSON.stringify(edge));
        this.relatedTo.edges.add(edge);
      }catch(e){

      }
    }


  }
  constructor() {  }

  ngOnInit() {

    // var x = `{
    //   "msg":{
    //     "Result":["로봇연구실"]
    //   },
    //   "ontology": {
    //     "RelatedFrom": [
    //       [
    //         "http://www.arbi.com/ontologies/arbi.owl#hasInnerPoint",
    //         "http://www.arbi.com/ontologies/arbi_map.owl#OfficeRoom001_InnerPoint001"
    //       ]
    //     ],
    //     "RelatedTo": [
    //      [
    //        "http://www.arbi.com/ontologies/arbi.owl#workPlace",
    //        "http://www.arbi.com/ontologies/GuideService.owl#ResearchDepartment001"
    //      ]
    //    ],
    //    "TypeClass": "http://knowrob.org/kb/knowrob.owl#OfficeRoom",
    //    "UpperClass": "http://knowrob.org/kb/knowrob.owl#RoomInAConstruction"
    //   }
    // }`
    //
    // this.visualizeOntology(x);

    var containerRT = document.getElementById('relatedTo');
    var containerRF = document.getElementById('relatedFrom');

    var options = {};
    var networkRT = new Network(containerRT, {"nodes":this.relatedTo.nodes,"edges":this.relatedTo.edges}, options);
    var networkRF = new Network(containerRF, {"nodes":this.relatedFrom.nodes,"edges":this.relatedFrom.edges}, options)


  }
}
