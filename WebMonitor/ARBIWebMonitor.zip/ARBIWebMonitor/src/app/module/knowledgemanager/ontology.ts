import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'ontology',
  template: `
  <div class="panel panel-default">
    <div class="panel-heading">
      Ontology File List
    </div>
    <ul class="list-group" *ngFor="let val of model">
      <li class="list-group-item">{{val}}</li>
    </ul>
  </div>
  `,
})
export class Ontology implements OnInit {
  @Input() model;
  constructor() {  }

  ngOnInit() {}
}
