import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'service-filelist',
  template: `
  <div class="panel panel-default">
    <div class="panel-heading">
      {{model.Title}}
    </div>
    <ul class="list-group" *ngFor="let val of model.Content">
      <li class="list-group-item">{{val}}</li>
    </ul>
  </div>
  `,
})
export class ServiceDispatcherFileListComponent implements OnInit {
  @Input() model:any;
  constructor() {  }

  ngOnInit() {}
}
