import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'service-fileview',
  template: `
  <div class="panel panel-default">
    <div class="panel-heading">
      {{title}}
    </div>
    <ul class="list-group" *ngFor="let val of model">
      <li class="list-group-item" (click)="val.isCollapsed = !val.isCollapsed">{{val.Name}}</li>
      <li class="list-group-item" [collapse]="val.isCollapsed">{{val.Content}}</li>
    </ul>
  </div>
  `,
})
export class ServiceDispatcherFileViewComponent implements OnInit {
  @Input() model:any;
  @Input() title:any;
  isCollapsed: boolean = false;

  // collapsed(event: any): void {
  //   console.log(event);
  // }
  //
  // expanded(event: any): void {
  //   console.log(event);
  // }

  constructor() {  }

  ngOnInit() {}
}
