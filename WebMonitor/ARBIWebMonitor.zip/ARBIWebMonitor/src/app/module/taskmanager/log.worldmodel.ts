import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'worldmodel-log',
  template: `<div class="panel panel-default">
  <div class="panel-heading">World Model Log</div>
    <table class="table table-fixed">
      <thead><tr>
      <th class="col-xs-1">#</th>
      <th class="col-xs-2">Time</th>
      <th class="col-xs-3">Action</th>
      <th class="col-xs-6">Content</th>
      </tr></thead>
      <tbody>
        <tr *ngFor="let val of model; let i = index">
          <td class="col-xs-1">{{i}}</td>
          <td class="col-xs-2">{{val.time}}</td>
          <td class="col-xs-3">{{val.action}}</td>
          <td class="col-xs-6">{{val.content}}</td>
        </tr>
      </tbody>
    </table>
  </div>`,
  styleUrls:['../../css/table-fixed.css']
})
export class WorldModelLog implements OnInit {
  @Input() model;
  constructor() {  }

  ngOnInit() {}
}
