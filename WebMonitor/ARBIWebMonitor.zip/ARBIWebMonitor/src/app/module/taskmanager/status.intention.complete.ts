import { Component, NgModule, Input } from '@angular/core'
import { MonitorModule } from '../base.module'

@Component({
  selector: 'intention-complete',
  template: `<base-module>
    <div class="panel panel-default">
      <div class="panel-heading">Goal Completed</div>
      <div class="panel-body"><ng-content></ng-content></div>
    </div>

  </base-module>`
})
export class IntentionComplete extends MonitorModule {
  @Input() mwidth:number;
  constructor(){
    super();
    this.moduleSubscribeMessage = '{}'
  }
}
