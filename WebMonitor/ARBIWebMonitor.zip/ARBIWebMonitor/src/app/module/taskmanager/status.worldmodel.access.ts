import { Component, NgModule, Input } from '@angular/core'
import { MonitorModule } from '../base.module'

@Component({
  selector: 'worldmodel-access',
  template: `<base-module>
  <div class="panel panel-default">
    <div class="panel-heading">Worldmodel Access Count</div>
    <div class="panel-body"><ng-content></ng-content></div>
  </div>
  </base-module>`
})
export class WorldModelAccess extends MonitorModule {
  @Input() mwidth:number;
  constructor(){
    super();
    this.moduleSubscribeMessage = '{}'
  }
}
