import { Component, NgModule, Input } from '@angular/core'
import { MonitorModule } from '../base.module'

@Component({
  selector: 'worldmodel-current',
  template: `<base-module>
  <div class="panel panel-default">
    <div class="panel-heading">Current Plan Count</div>
    <div class="panel-body"><ng-content></ng-content></div>
  </div>
  </base-module>`
})
export class WorldModelCurrent extends MonitorModule {
  @Input() mwidth:number;
  constructor(){
    super();
    this.moduleSubscribeMessage = '{}'
  }
}
