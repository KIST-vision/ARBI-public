import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'intention-structure',
  template: `<div class="panel panel-default">
    <div class="panel-heading">Intention Structure(Goal List)</div>
    <ul class="list-group scrollable">
      <li *ngFor="let val of model" class="list-group-item">{{val}}</li>
    </ul>
  </div>
  `,
})
export class IntentionStructure implements OnInit {
  @Input() model;
  constructor() {  }

  ngOnInit() {console.log(this.model)}
}
