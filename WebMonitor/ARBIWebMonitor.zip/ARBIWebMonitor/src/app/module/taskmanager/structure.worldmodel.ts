import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'worldmodel-structure',
  template: `<div class="panel panel-default">
    <div class="panel-heading">World Model</div>
    <ul class="list-group scrollable">
      <li *ngFor="let val of model" class="list-group-item">{{val}}</li>
    </ul>
  </div>
  `,
})
export class WorldModelStructure implements OnInit {
  @Input() model;
  constructor() {  }

  ngOnInit() {console.log(this.model)}
}
