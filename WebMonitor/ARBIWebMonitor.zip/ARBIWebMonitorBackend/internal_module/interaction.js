var express = require('express');
var router = express.Router();

var parseJson = require('parse-json');

var SSE = require("express-sse");
var sse = new SSE();
var bigsse = new SSE();

var stomp = require('stomp');

const STOMP_ARGS = {
  port: 61613,
  host: '192.168.1.41',
  debug: false,
  login: 'system',
  passcode: 'manager'
};

console.log(STOMP_ARGS.host);

const INTERACTION_QUEUE = "/queue/interactionManager";

var stompClient = new stomp.Stomp(STOMP_ARGS);

const MONITOR_ID = "web_monitor_" + Math.floor(Math.random()*100000+1);
const INTERACTION_MANAGER_ADDRESS = "agent://www.arbi.com/interactionManager";

router.get('/origin', sse.init);
// router.get('/big', bigsse.init);

const firstFilterJSON = {
	"ID":MONITOR_ID,
	"Action":"Create Monitor",
	"Protocol":"Stomp",
	"Filter":[
	{"LogType":"SystemLog", "Actor":"taskManager", "Type":"WorldModel", "Action":"Assert", "Flag":"true"},
        {"LogType":"SystemLog", "Actor":"taskManager", "Type":"WorldModel", "Action":"Retract", "Flag":"true"},

        {"LogType":"SystemLog", "Actor":"taskManager", "Type":"Goal", "Action":"New", "Flag":"true"},
        {"LogType":"SystemLog", "Actor":"taskManager", "Type":"Goal", "Action":"Unpost", "Flag":"true"},
        {"LogType":"SystemLog", "Actor":"taskManager", "Type":"Goal", "Action":"Intend", "Flag":"true"},

	{"LogType":"SystemLog","Actor":"contextManager","Type":"WorkingMemory","Action":"context","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"WorkingMemory","Action":"availableMemory","Flag":"true"},

	{"LogType":"SystemLog","Actor":"contextManager","Type":"ContextService","Action":"query","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"ContextService","Action":"notify","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"ContextService","Action":"subscribe","Flag":"true"},

	{"LogType":"SystemLog","Actor":"contextManager","Type":"Counting","Action":"monitor","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"Counting","Action":"perception","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"Counting","Action":"triple","Flag":"true"},

	{"LogType":"SystemLog","Actor":"contextManager","Type":"RobotContext","Action":"availableBattery","Flag":"true"},
	{"LogType":"SystemLog","Actor":"contextManager","Type":"RobotContext","Action":"LatestPerception","Flag":"true"},

        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"UPDATEOWL","Action":"updateOWL","Flag":"true"},

        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"INFERENCE","Action":"parseSentence","Flag":"true"},
        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"INFERENCE","Action":"pathFind","Flag":"true"},
        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"INFERENCE","Action":"conversationContent","Flag":"true"},

        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"KNOWLEDGEGT","Action":"insertSchedule","Flag":"true"},
        {"LogType":"SystemLog","Actor":"knowledgeManager","Type":"QueryType","Action":"QueryProperty","Flag":"true"},

        {"LogType":"SystemLog","Actor":"initiator","Action":"Load","Type":"Rule","Flag":"true"},
        {"LogType":"SystemLog","Actor":"initiator","Action":"Load","Type":"Plan","Flag":"true"},
        {"LogType":"SystemLog","Actor":"initiator","Action":"Load","Type":"Knowledge","Flag":"true"},
        {"LogType":"SystemLog","Actor":"initiator","Action":"Load","Type":"Robot","Flag":"true"},

	{"LogType":"MessageLog", "Type":"AgentMessage","Action":"Request", "Flag":"true"},
	{"LogType":"MessageLog", "Type":"AgentMessage","Action":"Response", "Flag":"true"},
	{"LogType":"MessageLog", "Type":"AgentMessage","Action":"Query", "Flag":"true"}
	]
}



	// {"LogType":"MessageLog", "Type":"LTMMessage","Action" :"AssertFact","Flag":"true"},
	// {"LogType":"MessageLog", "Type":"LTMMessage","Action" :"Result","Flag":"true"}

const endFilterJSON = {
	"ID":MONITOR_ID,
	"Action":"Delete Monitor"
}

console.log("MONITOR ID = " + MONITOR_ID);

function replaceAsync(str, re, callback) {
    // http://es5.github.io/#x15.5.4.11
    str = String(str);
    var parts = [],
        i = 0;
    if (Object.prototype.toString.call(re) == "[object RegExp]") {
        if (re.global)
            re.lastIndex = i;
        var m;
        while (m = re.exec(str)) {
            var args = m.concat([m.index, m.input]);
            parts.push(str.slice(i, m.index), callback.apply(null, args));
            i = re.lastIndex;
            if (!re.global)
                break; // for non-global regexes only take the first match
            if (m[0].length == 0)
                re.lastIndex++;
        }
    } else {
        re = String(re);
        i = str.indexOf(re);
        parts.push(str.slice(0, i), callback.apply(null, [re, i, str]));
        i += re.length;
    }
    parts.push(str.slice(i));
    return Promise.all(parts).then(function(strings) {
        return strings.join("");
    });
}

var dataStore = {
  LTMMessageStore : [],
  AgentMessageStore : [],
  SystemMessageStore : []
}

function interactionSandbox() {
  var args = Array.prototype.slice.call(arguments),
	callback = args.pop(),
	modules = (args[0] && typeof args[0] === 'string') ? args : args[0],
	i;

	if (!(this instanceof interactionSandbox)) {
		return new interactionSandbox(modules, callback);
	}

	if (!modules || modules === '*' || modules[0] === '*') {
		modules = [];
		for (i in interactionSandbox.modules) {
			if (interactionSandbox.modules.hasOwnProperty(i)) {
				modules.push(i);
			}
		}
	}

  this.updateSSEInit = function(){
    sse.updateInit(dataStore);
    // bigsse.updateInit(bigDataStore);
  }

  for ( i = 0; i < modules.length; i += 1) {
		interactionSandbox.modules[modules[i]](this);
	}

	callback(this);
}



interactionSandbox.modules = {
  stomp : function(box){
    box.subscribe = function(){
      stompClient.connect();
      var headers = {
        destination: '/queue/' + MONITOR_ID,
        ack:'client',
      };

      function messageCallback(body, headers){
        // console.log("BODYTYPE = " + typeof body + "\nBODYLENGTH = " + body.length);
        var b = body;
        var x = "";
        console.log(b);
		    if(typeof body == "string"){
          x = body.replace(/\\\\\\\\\\\\\\/g,"\\").replace(/(\\&)/g,"\\\\&")
          b = parseJson(x);
        }


		    box.parseARBIMessage(b);
      }

      stompClient.on('connected', function() {
				console.log("Hoi, World!");
				stompClient.send({
		            'destination': INTERACTION_QUEUE,
		            'body': JSON.stringify(firstFilterJSON),
		            'persistent': 'false'
		        }, true);
				// console.log(INTERACTION_QUEUE);
			    stompClient.subscribe(headers, messageCallback);
			    console.log('Connected');
			});

			stompClient.on('message', function(message) {
			    // console.log("HEADERS: " + sys.inspect(message.headers));
			    // console.log("BODY: " + message.body);
			    // console.log("Got message: " + message.headers['message-id']);
			    stompClient.ack(message.headers['message-id']);
			});

			stompClient.on('error', function(error_frame) {
			    console.log(error_frame.body);
			    stompClient.disconnect();
			});

    }
  },
  parser : function(box){
    box.parseARBIMessage = function(data){
      return new Promise((res, rej) => {
        var d;
    		var prom;

    		if(typeof data[0] == "string"){
          console.log("parse string...");
    			prom = replaceAsync(data[0], /\\/g, function(match, offset, string){return "\\";}).then(function(result){
    				return replaceAsync(result,/\\&(?!\\)/g,function(match, offset, string){return "\\\\&";});
    			}).then(function(result){
    				return replaceAsync(result,/\t/g,function(match, offset, string){return "\\t";});
    			}).then(function(result){
    				return replaceAsync(result,/\n/g,function(match, offset, string){return "\\n";});
    			}).then(function(result){
    				return replaceAsync(result,/\r/g,function(match, offset, string){return "\\r";})
    			}).then(function(result){
    				return replaceAsync(result,/\\\\\\&quot;/g,function(match, offset, string){return "\\\\&quot;";})
    			}).then(function(result){
    				return replaceAsync(result,/\\=/g,function(match, offset, string){return "\\\\=";})
    			}).then(function(result){
    				// console.log("REPLACE RESULT = " + result);
    				return new Promise(function(resolve, reject){
    					resolve(parseJson(result));
    				});
    			})
    		} else {
    			prom = new Promise(function(resolve, rejcect){
            console.log("ARBI Message is already Object!")
    				resolve(JSON.stringify(data[0]));
    			})
    		}

        prom.then(function(res){
    			// console.log("RES = " + (typeof res == "object")?util.inspect(res):res);
    			switch (res.LogType) {
		        case "MessageLog":
		          box.parseMessageLog(res);
		          break;
		        case "SystemLog":
		         box.storeSystemLog(res);
		        break;
		        default:
		          console.log("Log Type Error! data = " + res.toString());
		          break;
  	    	}

    		}, function(err){
    			console.log("PROMISE ERROR! : " + err);
    		});
      })


  		prom.then(function(res){
  			// console.log("RES = " + (typeof res == "object")?util.inspect(res):res);
  			switch (res.LogType) {
  		        case "MessageLog":
  		          box.parseMessageLog(res);
  		          break;
  		        case "SystemLog":
  		         box.storeSystemLog(res);
  		        break;
  		        default:
  		          console.log("Log Type Error! data = " + res.toString());
  		          break;
  	    	}

  		}, function(err){
  			console.log("PROMISE ERROR! : " + err);
  		});
    }

    box.parseMessageLog = function(data){
  		switch (data.Type) {
  			case "AgentMessage":
  				console.log("Agent Message Log Incomming!");
  				box.storeAgentMessage(data);
  				break;
  			case "CDCMessage":
  				console.log("CDC Message Log Incomming!");
  				box.storeLTMMessage(data);
  				break;
  			case "LTMMessage":
  				console.log("LTM Message Log Incomming!");
  				box.storeLTMMessage(data);
  				break;
  			default:
  				console.log("MessageLog Type Error! data = " + data.toString());
  				break;
  		}
  	}

    box.storeAgentMessage = function(data){
  		console.log("Agent Log incomming!")
  		var agentMessageLog = {
  			"Sender":data.Sender,
  			"Receiver":data.Receiver,
  			"Action":data.Action,
  			"Content":data.Content
  		}
  		dataStore.AgentMessageStore.push(agentMessageLog);
  		sse.send(agentMessageLog, 'agentMessage');
  		box.updateSSEInit();
  	}

  	box.storeLTMMessage = function(data){
  		console.log("LTM Log Incomming!")
  		var LTMMessageLog = {
      		"Client":data.Client,
      		"Action":data.Action,
      		"Content":data.Content
      	}
      	dataStore.LTMMessageStore.push(LTMMessageLog);
      	sse.send(LTMMessageLog, 'LTMessage');
      	box.updateSSEInit();
  	}

  	box.storeSystemLog = function(data){
  		var systemMessageLog;
  		if(typeof data.Content == "object"){
  			console.log("System log incomming! \nActor : " + data.Actor + "\nType:" + data.Type + "\nAction:"+data.Action+"\n");
  			console.log("SystemLogData = " + util.inspect(data, false, null));
        systemMessageLog = {
  				"Actor":data.Actor,
  				"Type":data.Type,
  				"Action":data.Action,
  				"Content":data.Content,
  				"Time":data.Time
  			}
        // systemMessageLog = {
  			// 	"Actor":data.Actor,
  			// 	"Type":data.Type,
  			// 	"Action":data.Action,
  			// 	"Time":data.Time
  			// }
  		} else {
  			if(!data.Content.includes("CURRENT_TIME" || !data.Content.includes("Tree(10,20)"))){
    			console.log("System log incomming! \nActor : " + data.Actor + "\nType:" + data.Type + "\nAction:"+data.Action+"\n");
          systemMessageLog = {
            "Actor":data.Actor,
            "Type":data.Type,
            "Action":data.Action,
            "Content":data.Content,
            "Time":data.Time
          }
    			// console.log("SystemLogData = " + util.inspect(data, false, null));
    			// systemMessageLog = {
    			// 	"Actor":data.Actor,
    			// 	"Type":data.Type,
    			// 	"Action":data.Action,
    			// 	"Time":data.Time
    			// }
    		}
  		}


      console.log("Datastore Pushed! ");

      systemMessageLog.Content = data.Content;
      dataStore.SystemMessageStore.push(systemMessageLog);
      sse.send(systemMessageLog,'systemMessage');

  		// console.log("Current Datastore : " + util.inspect(dataStore, false, null));

  		box.updateSSEInit();
  	};
  }
}

interactionSandbox.prototype = {
	name : "ARBI Web Monitor Interaction Manager",
	version : "0.1",
	getName: function() {
	return this.name;
	}
}

function exitHandler(options, err) {
    if (options.cleanup) console.log('clean');
    if (err) console.log(err.stack);
    if (options.exit) {
      console.log("time to Exit!");
      stompClient.send({
            'destination': INTERACTION_QUEUE,
            'body': JSON.stringify(endFilterJSON),
            'persistent': 'false',
        }, false);
      stompClient.disconnect();
      setTimeout(process.exit(), 500)
    }
}

interactionSandbox(function(box){
  console.log("Let's Begin!");
  box.subscribe();
})

//do something when app is closing
process.on('exit', exitHandler.bind(null,{cleanup:true}));

//catches ctrl+c event
process.on('SIGINT', exitHandler.bind(null, {exit:true}));

//catches uncaught exceptions
process.on('uncaughtException', exitHandler.bind(null, {exit:true}));

module.exports = router;
